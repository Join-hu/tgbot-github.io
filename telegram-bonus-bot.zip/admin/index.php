<?php
require '../config.php';

$total = $db->query("SELECT COUNT(*) as total FROM users")->fetch(PDO::FETCH_ASSOC);
$balances = $db->query("SELECT SUM(balance) as sum FROM users")->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
</head>
<body>
<h1>📊 Админ панель</h1>

<p>Пользователей: <?= $total['total'] ?></p>
<p>Общий баланс: <?= round($balances['sum'], 2) ?> ₽</p>

</body>
</html>
